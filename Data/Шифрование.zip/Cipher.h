/*
 * Cipher.h
 *
 *  Created on: 05.04.2012
 *      Author: kossov
 */

#ifndef CIPHER_H_
#define CIPHER_H_

#include <openssl/evp.h>

static const unsigned char STX = '\x12';
static const unsigned char ETX = '\x14';
static const unsigned char PAD = '\x16';

//------------------------------------------------------

class TCipher
{
public:
    static const int CIPHER_SEND_BUFF_SIZE = 2048;
    static const int CIPHER_RCV_BUFF_SIZE = 2048;

private:
    EVP_CIPHER_CTX cipher_ctx_send;
    EVP_CIPHER_CTX cipher_ctx_rcv;
    int cipher_block_size;
    unsigned char * cipher_buf_send;
    unsigned char * cipher_buf_rcv;
    unsigned char * cipher_buf_tmp;
    long cipher_encrypted, cipher_decrypted;
public:
    TCipher();
    ~TCipher();
    void Open(BYTE** outbuff_ptr, int* outlen, const unsigned char * cipherKey, int cipherKeySize);
    void Close(void);
    bool EncryptUpdate(BYTE** outbuff_ptr, int* outlen, const char* inpbuff, int inplen, int* inp_encrypted, bool flush=false);
    bool DecryptUpdate(BYTE** outbuff_ptr, int* outlen, const char* inpbuff, int inplen, int* inp_decrypted);
}; // class TCipher


#endif /* CIPHER_H_ */
