/*
 * Cipher.cpp
 *
 *  Created on: 05.04.2012
 *      Author: kossov
 */


#include <openssl/evp.h>
#include <openssl/rand.h>

#include "Cipher.h"

#define MY_CIPHER               EVP_bf_cbc()
#define SALT_LENGTH             4

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
TCipher::TCipher()
{
	cipher_block_size = EVP_CIPHER_block_size(EVP_bf_cbc());
	cipher_buf_send = (unsigned char *)malloc(CIPHER_SEND_BUFF_SIZE+cipher_block_size-1);
	cipher_buf_rcv = (unsigned char *)malloc(CIPHER_RCV_BUFF_SIZE+cipher_block_size);
	cipher_buf_tmp = (unsigned char *)malloc(cipher_block_size);
	cipher_encrypted = 0;
	cipher_decrypted = 0;

	EVP_CIPHER_CTX_init(&cipher_ctx_send);
	EVP_CIPHER_CTX_init(&cipher_ctx_rcv);
};
//---------------------------------------------------------------------------
TCipher::~TCipher()
{
	EVP_CIPHER_CTX_cleanup(&cipher_ctx_send);
	EVP_CIPHER_CTX_cleanup(&cipher_ctx_rcv);
	free(cipher_buf_tmp);
	free(cipher_buf_rcv);
	free(cipher_buf_send);
};
//---------------------------------------------------------------------------
void TCipher::Open(BYTE** outbuff_ptr, int* outlen, const unsigned char * cipherKey, int cipherKeySize)
{
	if(outbuff_ptr) *outbuff_ptr = NULL;
	if(outlen) *outlen = 0;

	int len;
	unsigned char * cipher_key;

	int cipher_key_len = EVP_CIPHER_key_length(MY_CIPHER);

	int keylen = cipher_key_len;
	if( (cipher_key = (unsigned char *)malloc(keylen)) != NULL ) {
		for(unsigned char * pck = cipher_key; keylen > 0; ) {
			len = keylen;
			if(len > cipherKeySize) len = cipherKeySize;
			memcpy(pck, cipherKey, len);
			pck += len;
			keylen -= len;
		}

		unsigned char cipher_iv[8];
		memset(cipher_iv, 0, sizeof(cipher_iv));

		EVP_EncryptInit_ex(&cipher_ctx_send, MY_CIPHER, NULL, cipher_key, cipher_iv);
		EVP_DecryptInit_ex(&cipher_ctx_rcv, MY_CIPHER, NULL, cipher_key, cipher_iv);

		free(cipher_key);
	}

	cipher_encrypted = 0;
	cipher_decrypted = 0;

	// salt - ��������� ��������� �����
	unsigned char rnd[SALT_LENGTH];
	for(int i=0; i<SALT_LENGTH; ) {
		RAND_pseudo_bytes(&rnd[i], 1);
		if(rnd[i] == STX || rnd[i] == ETX) continue;
		++i;
	}
	EVP_EncryptUpdate(&cipher_ctx_send, cipher_buf_send, &len, rnd, sizeof(rnd));
	cipher_encrypted += sizeof(rnd);

	if(outbuff_ptr) *outbuff_ptr = cipher_buf_send;
	if(outlen) *outlen = len;
};
//---------------------------------------------------------------------------
void TCipher::Close(void)
{
	int outlen;
	EVP_DecryptFinal_ex(&cipher_ctx_rcv, cipher_buf_rcv, &outlen);
	EVP_EncryptFinal_ex(&cipher_ctx_send, cipher_buf_send, &outlen);
};
//---------------------------------------------------------------------------
bool TCipher::EncryptUpdate(BYTE** outbuff_ptr, int* outlen, const char* inpbuff, int inplen, int* inp_encrypted, bool flush)
{
	*outbuff_ptr = NULL;
	*outlen = 0;
	*inp_encrypted = 0;

	int len = inplen;

	int maxlen = flush ? (CIPHER_SEND_BUFF_SIZE - 2*cipher_block_size) : CIPHER_SEND_BUFF_SIZE;
	if(len > maxlen) len = maxlen;

	if( ! EVP_EncryptUpdate(&cipher_ctx_send, cipher_buf_send, outlen, (const unsigned char*)inpbuff, len) ) return false;
	cipher_encrypted += len;
	*inp_encrypted = len;
	*outbuff_ptr = cipher_buf_send;

	if(flush) {
		memset(cipher_buf_tmp, PAD, cipher_block_size);

		// ������������� �� ������� �����
		int rem = (cipher_encrypted % cipher_block_size);
		if(rem > 0) {
			rem = cipher_block_size - rem;
			if( ! EVP_EncryptUpdate(&cipher_ctx_send, cipher_buf_send+(*outlen), &len, cipher_buf_tmp, rem) ) return false;
			cipher_encrypted += rem;
			*outlen += len;
		}

		// ��������� ���� ������������ ��� �������������� �����������
		if( ! EVP_EncryptUpdate(&cipher_ctx_send, cipher_buf_send+(*outlen), &len, cipher_buf_tmp, cipher_block_size) ) return false;
		cipher_encrypted += cipher_block_size;
		*outlen += len;
	}

	return true;
};
//---------------------------------------------------------------------------
bool TCipher::DecryptUpdate(BYTE** outbuff_ptr, int* outlen, const char* inpbuff, int inplen, int* inp_decrypted)
{
	*outbuff_ptr = NULL;
	*outlen = 0;
	*inp_decrypted = 0;

	int len = inplen;

	int maxlen = CIPHER_RCV_BUFF_SIZE;
	if(len > maxlen) len = maxlen;

	if( ! EVP_DecryptUpdate(&cipher_ctx_rcv, cipher_buf_rcv, &len, (const unsigned char*)inpbuff, len) ) return false;
	int _decr = cipher_decrypted;

	cipher_decrypted += len;
	*inp_decrypted = len;

	if(_decr < SALT_LENGTH) {
		int len_to_throw = SALT_LENGTH - _decr;
		if(len_to_throw < len) {
			len -= len_to_throw;
			memmove(cipher_buf_rcv, cipher_buf_rcv+len_to_throw, len);
		} else {
			return true;
		}
	}

	*outbuff_ptr = cipher_buf_rcv;
	*outlen = len;
	return true;
};
